public class Item {
    public int qntd;
    public float preco;
    public String nome;
    public Item(int qntd, float preco, String nome){
        this.qntd = qntd;
        this.preco = preco;
        this.nome = nome;
    }
}
